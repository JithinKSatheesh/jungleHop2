
var rewardedSlot, isRewardedSlotGranted = false, isRewardedAdClosedByUser = false, isSlotReady = false;

function rewardedAd(){

    googletag = window.googletag || {cmd: []};
  
    googletag.cmd.push(() => { 

        googletag.pubads().addEventListener('rewardedSlotReady',
            function(evt) {
            console.log("!!rewardedSlotReady...");
            isSlotReady = true;
            console.log(evt);
            evt.makeRewardedVisible();
        });

        googletag.pubads().addEventListener('rewardedSlotGranted',
        function(evt) {
            console.log("YES!! reward granted!!!");
            console.log(evt);
            isRewardedSlotGranted = true;
        });


        googletag.pubads().addEventListener('rewardedSlotClosed',
        function(evt) {
            console.log("Closed by the user!");
            console.log(evt);
            isRewardedAdClosedByUser = true;
            runOnAdClosed();
            googletag.destroySlots([rewardedSlot]);
        });
        
        if(gpID != "$GPID" && gpID != "" && gpID != null){
            googletag.pubads().setPublisherProvidedId(encryptGPID(gpID));
        }
        else{
            console.log("GPID not populated properly");
        }
        googletag.enableServices();
    });
}

function displayRewardAd(){
    console.log("index.html :: displayRewardAd()");
    googletag.cmd.push(() => { 
        rewardedSlot = googletag.defineOutOfPageSlot(
                    'RewardAdUnit',
                    googletag.enums.OutOfPageFormat.REWARDED)
                    .addService(googletag.pubads());
        googletag.display(rewardedSlot);
    });
}

function destroyAdSlot(){
    console.log('destroing the ad slot....');
    googletag.cmd.push(() =>{
    googletag.destroySlots([rewardedSlot]);
    });
}

function showRewardedAd(){
    console.log("showRewardedVideo();");

    isRewardedSlotGranted = false;
    isRewardedAdClosedByUser = false;
    isSlotReady = false;
    
    displayRewardAd();
    
    var waitTime = 0;
    
    (function wait() {
        if (isRewardedSlotGranted) {
            console.log("Yes! reward is granted :) all is well..");
            
        } else {
            waitTime++;
            console.log("wait time = " + waitTime);
            if(isSlotReady && isRewardedAdClosedByUser){
                console.log(".....reward is not granted :(");
                console.log("user is not interested in ad anymore...");
                // destroyAdSlot();
                // callback({rewardGranted: false});
            }
            else if(waitTime <= 6){
                setTimeout(wait, 1000 );
            } else{
                console.log("reward not granted within 6s..");
                runOnAdClosed();
                // destroyAdSlot();
                // callback({rewardGranted: false});
            }
        }
    })();
}