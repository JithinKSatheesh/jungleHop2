
var gpID = getGPID();

function encryptGPID(gpid){

    let encryptedGPID = CryptoJS.MD5(gpid).toString()
    return encryptedGPID
}

function getGPID(){
    return location.search.substring(1).split("&").find((a) => {return a.startsWith('gpid')}).split("=")[1]
}