var stickyBannerSlot;
var stickyBannerAdUnit = "StickyAdUnit";


function addStickyBannerAd(){
    // GPT banner ad code goes here
    
    window.googletag = window.googletag || {
        cmd: []
    };
    googletag.cmd.push(function () {
        stickyBannerSlot = googletag
            .defineSlot(
                stickyBannerAdUnit, [
                    [320, 50],
                    [300, 50]
                ], 'banner-ad')
            .setTargeting('refresh', 'true')
            .addService(googletag.pubads());

        if(gpID != "$GPID" && gpID != "" && gpID != null){
            googletag.pubads().setPublisherProvidedId(encryptGPID(gpID));
        }
        else{
            console.log("GPID not populated properly");
        }

        googletag.pubads().enableSingleRequest(); 
        googletag.enableServices();
    });
    //GPT banner ad code ends here

}


//This function will ad the stickyBanner UI
function addStickyBanner() {
    var stickyBannerDiv = `<div id="bannerOverlay">
                            <div id="banner-ad">
                                <script>
                                    googletag.cmd.push(function () {
                                        googletag.display('banner-ad');
                                    });
                                </script>
                            </div>
                        </div>`;

    $("body").append($(stickyBannerDiv));
    console.log("stickyBannerDiv added...");
}


function refreshStickyBanner(refreshIntervalms) {
    showStickyBannerAd(); //making display = "flex"
    console.log('refresh the sticky banner ad each ',refreshIntervalms/1000, 's');
    var timesRun = 0;
    const runInterval = setInterval(()=> {
        timesRun += 1;
        if (timesRun === 10000) {
            clearInterval(runInterval);
        }
        //refreshing the ad at 30s interval
        googletag.cmd.push(function() {
          googletag.pubads().refresh([stickyBannerSlot]);
        });
    }, refreshIntervalms);
}

function showStickyBannerAd(){
    $("#bannerOverlay").css("display","flex");
}