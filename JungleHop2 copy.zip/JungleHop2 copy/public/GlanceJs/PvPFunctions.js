// --------------------------------------
var gamePlay = true;
var gameCurrentScore = 0;
var getCurrentHighScore = 0;
var gameCurrentlife = 1;
//  gameStoppedDueToGameTimer = true;
livesForGame = 3;
timerForGame = 3;

// --------------------------------------

function startGame() {
    console.log("startGame()");
    sendCustomAnalyticsEvent("game_start", {});
    gamePlay = false;

    //starting timer 
    gameStoppedDueToGameTimer = false;
    startTimer(timerDuration);

    // Calling to unity start game
    UnityStartGame();


}


function replayEvent() {
    //resetting timer
    gameStoppedDueToGameTimer = false;
    startTimer(timerForGame);
    // Resetting Lives 
    // noOfLives = livesForGame; 
    UnityRestartGame();
}

// -------------------------------------
// recurring call from unity
// -------------------------------------
function setGameScore(score, highscore) {
    gameCurrentScore = parseInt(score);
    getCurrentHighScore = parseInt(highscore)
    pvpBridge.setYourScore(getScore);
}

function setGameLife(life) {
    gameCurrentlife = parseInt(life);
}

function callLifeLoss(){
    // setScore(getScore() - penaltyOnLifeLoss);
    // showPenaltyOverLay();
    // pvpBridge.setYourScore(getScore);

}

function callUpdate() {
    Update();
}


// =====================================
// PVP
// =====================================

function gameStart() {
    // alert("called")

    if (gamePlay) {

        if (pvpBridge.isPvpEnabled()) {
            console.log("PVP MODE");
            pvpBridge.launchPvp(startGame, "7e578260-e627-11ec-aa12-273787abbe0f", replayEvent);
        }
        else {
            startGame();
        }
    } else {

        // const hScore = 0;
        sendCustomAnalyticsEvent("game_replay", { score: 0, highscore: getCurrentHighScore });
        replayEvent();
        // UnityRestartGame();

    }


}


function getScore() {
    return gameCurrentScore;
}

function setScore(score_) {
    unityInstance.SendMessage("GameManager", "setScore", score_)
}

function GameEnd() {
    unityInstance.SendMessage("GameManager", "EndGame")
    pvpBridge.showResult();
}

function Update () {
    // Any function here will call repeatedly
    if(gameStoppedDueToGameTimer){
        // alert("Timeout")
        GameEnd();
     }
}

function getLives(){
    return gameCurrentlife;
}

function setLives(){
    unityInstance.SendMessage("GameManager", "setScore", score_)
}

function getAllUIElementsInGame(){
    console.log("Not applicable!! :( ")
}