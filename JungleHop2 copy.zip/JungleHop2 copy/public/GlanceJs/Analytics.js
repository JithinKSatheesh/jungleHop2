const isSdkNew_glance = typeof GlanceAndroidInterface !== "undefined" ? true : false;

function sendCustomAnalyticsEvent(eventType, extras) {
    console.log("sendCustomAnalyticsEvent", eventType, extras);
    if (isSdkNew_glance) {
        const data = JSON.stringify(extras);
        GlanceAndroidInterface.sendCustomAnalyticsEvent(eventType, data);
    }
}

var leaderBoard_called = false;
var gameEnd_called = false;

// ================================================
// ----> analytics functions will be called from unity
// ================================================

function analytics_game_Load () {
    // alert("Game load")
    sendCustomAnalyticsEvent("game_load", {});
    refreshStickyBanner(30000);
    
}

// **** moved to pvpFunctions

function analytics_game_start () {
    // alert("Game start")
    console.log("Game start.........")
    sendCustomAnalyticsEvent("game_start", {}); 
    leaderBoard_called = false;
    gameEnd_called = false;
    // startGame();
}

function showGameOverScreen (score) {
    // console.log("leader called again!")
    if(leaderBoard_called === false) {
        showLeaderBoard(parseInt(score));
        leaderBoard_called = true;
    }
}

function analytics_game_reply(score, highScore){
    // alert("relpay")
    sendCustomAnalyticsEvent("game_replay", { score:0, highScore: parseInt(highScore) });
    leaderBoard_called = false;
    gameEnd_called = false;
}

function analytics_game_end(score, highScore){
    if(gameEnd_called === false) {
        // alert("Game End")
        sendCustomAnalyticsEvent("game_end", { score : parseInt(score), highScore: parseInt(highScore) });
        gameEnd_called = true;
    }
}

// ====================================
// Send message to unity
// ====================================
function UnityStartGame () {
    unityInstance.SendMessage("MainMenuController", "PlayGameScene")
}

function UnityRestartGame () {
    unityInstance.SendMessage("GameplayControl", "RestartGame")
    // alert("here")
    // unityInstance.SendMessage("MainMenuController", "PlayGame")
}

