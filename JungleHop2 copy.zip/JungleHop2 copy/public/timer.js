
var windowUrlpvp = window.location.href;
var splittedUrlpvp = windowUrlpvp.split("?");
var allParamsPvp = splittedUrlpvp.length>1 ? splittedUrlpvp[1].split("&") : [];

//if lives and timer are not provided in the URL
//then the game will consider default values i.e, -1
var livesForGame = -1; //default is -1 for UNLIMITED LIVES
var timerForGame = -1; //default is -1 for NO TIMER
var oldTimerUI = 0; 

//specifically for this game
var penaltyOnLifeLoss = 50; //default is 50
var penaltyOnBombHit = "all";//can take "all" or "half"

//demo URL : https://link-to-game.html?lives=2&timer=60  

//the below function is to get params index so that sequence of params won't matter
function getParamIndex(substring){
    var ind = allParamsPvp.findIndex(element => {
        if (element.includes(substring)) {
          return true;
        }
    });

    return ind;
} 

var livesIndex = getParamIndex("lives");
var timerIndex = getParamIndex("timer");
var penaltyLifeIndex = getParamIndex("penaltyOnLifeLoss");
var penaltyBombIndex = getParamIndex("penaltyOnBombHit");
var oldTimerIndex = getParamIndex("oldTimer");


if(allParamsPvp.length>0){
    livesForGame = livesIndex>=0 ? allParamsPvp[livesIndex].split("=")[1] : -1; 
    timerForGame = timerIndex>=0 ? allParamsPvp[timerIndex].split("=")[1] : -1;
    penaltyOnLifeLoss = penaltyLifeIndex>=0 ? allParamsPvp[penaltyLifeIndex].split("=")[1] : 50;  
    penaltyOnBombHit = penaltyBombIndex>=0 ? allParamsPvp[penaltyBombIndex].split("=")[1] : "all"; 
    oldTimerUI = oldTimerIndex>=0 ? allParamsPvp[oldTimerIndex].split("=")[1] : 0; 
}


let noOfLives = livesForGame;
let gameStoppedDueToGameTimer = false;
let timerDuration = timerForGame;

function startTimer(timerDurationInSec){
    var timeRemaining = timerDurationInSec;

    if(timerDurationInSec<0){
        console.log("Timer is set to negative which means NO TIMER concept");
        hideOverLayTimerDiv();
    }

    else{
        if(oldTimerUI){
            showOverLayTimerDiv();
        }
        
        var minutes = Math.floor(timeRemaining  / 60);
        var seconds = Math.floor(timeRemaining % 60);
        
        // Setting the initial overLay Text here
        document.getElementById("overlayTextTimer").innerHTML = minutes + "m " + seconds + "s ";
        // Update the count down every 1 second
        var timer = setInterval(function() {

            timeRemaining -= 1;
            
            // Time calculations for days, hours, minutes and seconds
            
            var minutes = Math.floor(timeRemaining  / 60);
            var seconds = Math.floor(timeRemaining % 60);
            
            // updating the overlayText here
            document.getElementById("overlayTextTimer").innerHTML = minutes + "m " + seconds + "s ";

            // console.log(minutes + "m " + seconds + "s ");

            if(noOfLives == 0){
                clearInterval(timer);
                console.log("LIFE OVER ---- TIMER STOPPED");
                hideOverLayTimerDiv()
            }
            
            // If the count down is over, write some text 
            if (timeRemaining <= 0) {
                clearInterval(timer);
                console.log("EXPIRED");
                gameStoppedDueToGameTimer = true;
                hideOverLayTimerDiv();
            }
        }, 1000);
    }
}

function addOverLayTimerDiv(){
    var overLayDiv = `<div id = "overlayTimer">
                        <div id="overlayTextTimer"></div>
                    </div>`;

    $("body").append($(overLayDiv));
    console.log("OverLayTimerDiv added...");
}

function showOverLayTimerDiv(){
    $("#overlayTimer").css("display", "block");
}

function hideOverLayTimerDiv(){
    $("#overlayTimer").css("display", "none");
}

function addPenaltyOverLay(){
    var penaltyOverLay = `<div id = "penaltyOverlay">
                            <div id="penaltyOverlayText">-`+penaltyOnLifeLoss+` Penalty </div>
                        </div>`;

    $("body").append($(penaltyOverLay));
    console.log("penaltyOverLay added...");
}

function showPenaltyOverLay(){
    $("#penaltyOverlay").css("display", "block");
    $('#penaltyOverlay').delay(1000).fadeOut();
}